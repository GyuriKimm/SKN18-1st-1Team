import pygame
import random

# 초기화
pygame.init()

# 화면 크기
screen_width = 480
screen_height = 640
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("똥 피하기 게임")

# FPS 설정
clock = pygame.time.Clock()

# 캐릭터 설정
character = pygame.image.load("C:/dev/1.png")  # 캐릭터 이미지 필요
character_size = character.get_rect().size
character_width = character_size[0]
character_height = character_size[1]
character_x = (screen_width / 2) - (character_width / 2)
character_y = screen_height - character_height
character_speed = 10

# 똥 설정
ddong = pygame.image.load("C:/dev/1.png")  # 똥 이미지 필요
ddong_size = ddong.get_rect().size
ddong_width = ddong_size[0]
ddong_height = ddong_size[1]
ddong_x = random.randint(0, screen_width - ddong_width)
ddong_y = 0
ddong_speed = 7

# 폰트
game_font = pygame.font.Font(None, 40)

# 게임 루프
running = True
while running:
    dt = clock.tick(30)  # 초당 프레임 수

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 키 입력 처리
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        character_x -= character_speed
    if keys[pygame.K_RIGHT]:
        character_x += character_speed

    # 캐릭터 벽 밖으로 못 나가게
    if character_x < 0:
        character_x = 0
    elif character_x > screen_width - character_width:
        character_x = screen_width - character_width

    # 똥 떨어지기
    ddong_y += ddong_speed
    if ddong_y > screen_height:
        ddong_y = 0
        ddong_x = random.randint(0, screen_width - ddong_width)

    # 충돌 처리
    character_rect = character.get_rect(topleft=(character_x, character_y))
    ddong_rect = ddong.get_rect(topleft=(ddong_x, ddong_y))

    if character_rect.colliderect(ddong_rect):
        text = game_font.render("게임 오버!", True, (255, 0, 0))
        screen.blit(text, (150, 250))
        pygame.display.update()
        pygame.time.delay(2000)
        running = False

    # 화면 그리기
    screen.fill((135, 206, 235))  # 하늘색 배경
    screen.blit(character, (character_x, character_y))
    screen.blit(ddong, (ddong_x, ddong_y))
    pygame.display.update()

# 게임 종료
pygame.quit()
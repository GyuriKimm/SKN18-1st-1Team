import streamlit as st

st.title("자동차 데이터 분석")
